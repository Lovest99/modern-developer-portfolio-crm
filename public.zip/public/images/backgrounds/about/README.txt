ABOUT SECTION BACKGROUND IMAGE

Place your background image here with the filename "background.jpg"

Recommended specifications:
- Resolution: At least 1920x1080 pixels for good quality on larger screens
- Format: JPG (as specified)
- File size: Optimized for web (typically under 500KB)
- Content: Choose an image that complements your portfolio's theme and doesn't distract from the text

Good image choices might include:
- Subtle abstract patterns
- Blurred workspace photos
- Minimalist tech-related imagery
- Gradient-based designs with texture

Remember that text will be displayed over this image, so avoid images with high contrast or busy patterns that might make text difficult to read.
