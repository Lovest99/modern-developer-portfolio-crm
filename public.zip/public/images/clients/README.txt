IMPORTANT: Please add the following PNG logo files to this directory:

1. sichel-technologies.png
2. mist-corporate.png
3. golden-hearts.png
4. chigs-international.png
5. finmas.png
6. simrac.png
7. zimra.png
8. oriental.png
9. venice-mine.png
10. smart-stay.png
11. rudopos.png
12. manufacturepro.png
13. homelovers.png
14. drop.png
15. sichel-energies.png
16. placeholder-logo.png (for fallback)

These PNG files are needed for the TrustedBySection component to display your client logos properly.

Logo requirements:
1. Transparent background (PNG format)
2. Similar dimensions for all logos (recommended: 200-300px width)
3. Optimized file size (under 100KB each if possible)
4. Clear, high-quality images that look good on both light and dark backgrounds
